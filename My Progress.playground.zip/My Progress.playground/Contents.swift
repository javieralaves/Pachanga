import Cocoa

var cwcProgress: Double = 19 / 32
var hundredDaysProgress: Double = 14 / 100
var totalProgress: Double = (cwcProgress + hundredDaysProgress) / 2
var remainingProgress: Double = (1 - totalProgress)

// Days since June 15, inclusive
var daysPast: Int = 11

var daysRemaining: Int = 30 - daysPast

var expectedDailyProgress: Double = remainingProgress / Double(daysRemaining)
var currentDailyProgress: Double = totalProgress / Double(daysPast)

func calcPace() -> String {
    if currentDailyProgress > expectedDailyProgress {
        return "Good pace, keep it up!"
    } else {
        return "Pick up the pace!"
    }
}

calcPace()
